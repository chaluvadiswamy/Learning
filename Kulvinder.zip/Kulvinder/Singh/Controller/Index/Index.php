<?php

namespace Kulvinder\Singh\Controller\Index;


class Index extends \Magento\Framework\App\Action\Action {

	/** @var  \Magento\Framework\View\Result\Page */
    protected $resultPageFactory;
   /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory resultPageFactory
     */
    public function __construct(
	   \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
		)     
		{
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
        }
 
	/**
     * Default customer account page
     *
     * @return void
     */
	public function execute()
	{
		
		$this->getResponse()->appendBody('Hello world');
		return $this->resultPageFactory->create();

	}
}